﻿using System;

namespace RepositorioAPI.Models
{
    public class Repositorio
    {
        public int Id { get; set; }
        public required string Nome { get; set; }
        public required string Descricao { get; set; }
        public required string Linguagem { get; set; }
        public DateTime UltimaAtualizacao { get; set; }
        public required string Dono { get; set; }
        public bool Favorito { get; set; }
    }
}