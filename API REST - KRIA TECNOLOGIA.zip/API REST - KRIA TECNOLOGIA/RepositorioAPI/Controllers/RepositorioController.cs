﻿using System;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RepositorioAPI.Data;
using RepositorioAPI.Models;

namespace RepositorioAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RepositorioController : ControllerBase
    {
        private readonly AppDbContext _context;

        public RepositorioController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var repositorios = await _context.Repositorios.ToListAsync();
            return Ok(repositorios);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var repositorio = await _context.Repositorios.FindAsync(id);
            if (repositorio == null)
                return NotFound();
            return Ok(repositorio);
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Repositorio repositorio)
        {
            if (string.IsNullOrEmpty(repositorio.Nome))
                return BadRequest("Nome é obrigatório.");

            repositorio.UltimaAtualizacao = DateTime.UtcNow;
            _context.Repositorios.Add(repositorio);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetById), new { id = repositorio.Id }, repositorio);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] Repositorio repositorio)
        {
            var existente = await _context.Repositorios.FindAsync(id);
            if (existente == null) return NotFound();

            existente.Nome = repositorio.Nome;
            existente.Descricao = repositorio.Descricao;
            existente.Linguagem = repositorio.Linguagem;
            existente.UltimaAtualizacao = DateTime.UtcNow;

            await _context.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var repositorio = await _context.Repositorios.FindAsync(id);
            if (repositorio == null) return NotFound();

            _context.Repositorios.Remove(repositorio);
            await _context.SaveChangesAsync();
            return NoContent();
        }

        [HttpGet("meus-repositorios")]
        public async Task<IActionResult> GetMeusRepositorios([FromQuery] string dono)
        {
            var repositorios = await _context.Repositorios
                .Where(r => r.Dono.Contains(dono))
                .ToListAsync();
            return Ok(repositorios);
        }

        [HttpGet("buscar-repositorios")]
        public async Task<IActionResult> SearchRepositorios([FromQuery] string nome)
        {
            var repositorios = await _context.Repositorios
                .Where(r => r.Nome.Contains(nome))
                .ToListAsync();
            return Ok(repositorios);
        }

        [HttpPost("favoritar/{id}")]
        public async Task<IActionResult> Favoritar(int id)
        {
            var repositorio = await _context.Repositorios.FindAsync(id);
            if (repositorio == null) return NotFound();

            repositorio.Favorito = true;
            await _context.SaveChangesAsync();
            return NoContent();
        }

        [HttpGet("favoritos")]
        public async Task<IActionResult> GetFavoritos()
        {
            var repositoriosFavoritos = await _context.Repositorios
                .Where(r => r.Favorito)
                .ToListAsync();
            return Ok(repositoriosFavoritos);
        }
    }
}