﻿using RepositorioAPI.Data;
using RepositorioAPI.Models;
using System.Linq;

namespace RepositorioAPI.Services
{
    public class RepositorioService
    {
        private readonly AppDbContext _context;

        public RepositorioService(AppDbContext context)
        {
            _context = context;
        }

        public IQueryable<Repositorio> SearchRepositorios(string nome)
        {
            return _context.Repositorios.Where(r => r.Nome.Contains(nome));
        }

        public IQueryable<Repositorio> GetMeusRepositorios(string dono)
        {
            return _context.Repositorios.Where(r => r.Dono.Contains(dono));
        }

        public async Task MarkAsFavorito(int id)
        {
            var repositorio = await _context.Repositorios.FindAsync(id);
            if (repositorio != null)
            {
                repositorio.Favorito = true;
                await _context.SaveChangesAsync();
            }
        }
    }
}
